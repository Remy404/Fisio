//
//  BotonType.swift
//  MoveWare
//
//  Created by Alumno on 27/02/24.
//

import Foundation
import SwiftUI

struct Type: Hashable, Identifiable, Codable {
    
    var id: Int
    var name: String
    var window: String
    
    init(id: Int, name: String, window: String) {
        self.id = id
        self.name = name
        self.window = window
    }
}



