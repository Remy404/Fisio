//
//  ContentView.swift
//  MoveWare
//
//  Created by Alumno on 26/02/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            Text("FISIO")
                .navigationTitle(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=Title@*/Text("Title")/*@END_MENU_TOKEN@*/)
                .foregroundColor(Color.black)
                
            HStack {
                
                // Primer panel
                PanelView()
                    .scaledToFill()
                
                // Segundo panel
                PanelEstadisticaView()
                    
                
            }
            
            .background(Color.white.opacity(0.5)) // Cambia el color de fondo de la pantalla completa si lo deseas
        }
        }
        
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


