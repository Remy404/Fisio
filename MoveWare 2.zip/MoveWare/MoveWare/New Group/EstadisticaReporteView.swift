import SwiftUI

struct EstadisticasReporteView: View {
  
  let totalRepeticiones: Int = 100
  let tiempoTotal: Double = 1200.0
  let progresoRutina: Double = 0.75
  
  var body: some View {
    VStack(alignment: .leading) {
        
      Text("Estadísticas de Entrenamiento")
        .font(.title)
        .padding(.bottom, 5)
        .foregroundColor(.black)
        
      
      HStack {
        Text("Repeticiones:")
              .foregroundColor(.black)
          .bold()
        Text("\(totalRepeticiones)")
      }
      .foregroundColor(.black)
      
      HStack {
        Text("Tiempo total:")
          .bold()
        Text(String(format: "%.2f", tiempoTotal) + " s")
      }
      .foregroundColor(.black)
      
      HStack {
        Text("Progreso en rutina:")
          .bold()
        Text(String(format: "%.2f", progresoRutina) + "%")
      }
      .foregroundColor(.black)
        Image("estadisticasfija")
      
      // Agregar más estadísticas según sea necesario
    }
    .padding()
    .background(Color.white.opacity(0.5))
    .cornerRadius(10)
    .shadow(radius: 10)
    .frame(maxWidth: 500, maxHeight: 400) // Asigna un tamaño personalizado combinando dos tamaños predefinidos

  }
}
struct EstadisticasView_Previews: PreviewProvider {
  static var previews: some View {
    EstadisticasReporteView()
  }
}

