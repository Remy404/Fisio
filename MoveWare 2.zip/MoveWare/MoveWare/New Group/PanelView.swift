//
//  PanelView.swift
//  MoveWare
//
//  Created by Alumno on 26/02/24.
//

import SwiftUI


struct PanelView: View {
    var body: some View {
        VStack {
            NavigationStack{
                VStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/) {
                    // Aquí puedes agregar cualquier contenido que desees en tu panel
                    
                    Button(action: {
                        // Acción del botón
                    }) {
                        NavigationLink(destination: Rutina()) {
                            Text(botonTypes[0].name)
                                .scaledToFit()
                        }
                    }
                    .padding()
                    .background(Color.blue.opacity(0.2))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    Button(action: {
                        // Acción del botón
                    }) {
                        NavigationLink(destination: AbrirRutina()) {
                            Text(botonTypes[1].name)
                                .scaledToFit()
                        }
                    }
                    .padding()
                    .background(Color.blue.opacity(0.2))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    Button(action: {
                        // Acción del botón
                    }) {
                        NavigationLink(destination: EstadisticasReporteView()) {
                            Text(botonTypes[2].name)
                                .scaledToFit()
                        }
                    }
                    .padding()
                    .background(Color.blue.opacity(0.2))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    Button(action: {
                        // Acción del botón
                    }) {
                        NavigationLink(destination: ajustesView()) {
                            Text(botonTypes[3].name)
                                .scaledToFit()
                        }
                    }
                    .padding()
                    .background(Color.blue.opacity(0.2))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    
                    // Puedes agregar más contenido aquí según sea necesario
                }
            }
                    .environment(\.colorScheme, .light)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                
            
        }
    }
    struct PanelView_Previews: PreviewProvider {
        static var previews: some View {
            PanelView()
        }
    }
}
