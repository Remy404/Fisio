//
//  abrirRutina.swift
//  MoveWare
//
//  Created by Alumno on 04/03/24.
//

import Foundation
import SwiftUI

struct AbrirRutina: View {
    var body: some View {
            VStack {
                Text("MENU")
                    .font(.title)
                    .padding()

                // Menú con 4 espacios, cada uno con el texto "Nueva ranura"
                ForEach(0..<3){ index in
                    HStack{
                        ForEach(0..<2) { innerIndex in
                            NavigationLink(destination: Rutina()) {
                                Text("Rutina")
                                    .font(.system(size: 40))
                                    .padding(30)
                                    .scaledToFit()
                                    .background(Color.blue.opacity(0.2))
                                    .clipShape(RoundedRectangle(cornerRadius: 20))
                            }
                            .padding()
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.cyan.opacity(0.2))
            .clipShape(RoundedRectangle(cornerRadius: 20))
        
        }
    }




struct AbrirRutina_Previews: PreviewProvider {
    static var previews: some View {
        AbrirRutina()
    }
}

