
//
//  PanelView.swift
//  MoveWare
//
//  Created by Alumno on 26/02/24.
//

import SwiftUI

struct ajustesView: View {
    var body: some View {
        VStack {
            // Aquí puedes agregar cualquier contenido que desees en tu panel
            NavigationStack{
                Button(action: {
                    // Acción del botón
                }) {
                    NavigationLink(destination: AbrirRutina()) {
                        Text(botonTypes[5].name)
                            .scaledToFill()
                    }
                }
                .padding()
                .background(Color.blue.opacity(0.2))
                .clipShape(RoundedRectangle(cornerRadius: 20))
                Button(action: {
                    // Acción del botón
                }) {
                    NavigationLink(destination: AbrirRutina()) {
                        Text(botonTypes[6].name)
                            .scaledToFill()

                        
                    }
                }
                .padding()
                .background(Color.blue.opacity(0.2))
                .clipShape(RoundedRectangle(cornerRadius: 20))
                Button(action: {
                    // Acción del botón
                }) {
                    NavigationLink(destination: AbrirRutina()) {
                        Text(botonTypes[7].name)
                            .scaledToFill()
                    }
                }
                .padding()
                .background(Color.blue.opacity(0.2))
                .clipShape(RoundedRectangle(cornerRadius: 20))
                
                // Puedes agregar más contenido aquí según sea necesario
            }
        }
    }
}
    
    struct ajustesView_Previews: PreviewProvider {
        static var previews: some View {
            ajustesView()
        }
    }

