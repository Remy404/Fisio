//
//  nuevaRutina.swift
//  MoveWare
//
//  Created by Alumno on 04/03/24.
//

import SwiftUI

struct nuevaRutina: View {
    let ejerciciosAñadidos = ["Ejercicio 1", "Ejercicio 2", "Ejercicio 3"]
    let ejerciciosPool = ["Ejercicio A", "Ejercicio B", "Ejercicio C"]
    let listaDetalles = ["sets: 3, reps: 5", "sets: 5, reps: 5", "sets: 5, reps: 3"]

    var body: some View {

            HStack {
                // Menú a la izquierda
                VStack(alignment: .leading) {
                    Text("Añadidos")
                        .font(.system(size: 50))
                    ForEach(0..<ejerciciosAñadidos.count) { index in
                        NavigationLink(destination: Text("Detalles de \(self.ejerciciosAñadidos[index])")) {
                            Text("\(index + 1). \(self.ejerciciosAñadidos[index])")
                                .font(.system(size: 30))
                                .padding()
                                .background(Color.blue.opacity(0.2))
                                .clipShape(RoundedRectangle(cornerRadius: 20))
                                .foregroundColor(.black)
                        }
                        .padding(.top, 10)
                    }
                }
                .padding()
                .frame(width: 250, alignment: .leading)

                // Ventana principal con menú de ejercicios a la derecha
                VStack(alignment: .leading) {
                    Text("Menú de Ejercicios")
                        .font(.system(size: 50))
                        .padding()

                    ForEach(0..<ejerciciosPool.count) { index in
                        NavigationLink(destination: Text("Detalles de \(self.ejerciciosPool[index])")) {
                            Text("\(self.ejerciciosPool[index])")
                                .font(.system(size: 30))
                                .padding()
                                .background(Color.blue.opacity(0.2))
                                .clipShape(RoundedRectangle(cornerRadius: 20))
                                .foregroundColor(.black)
                        }
                        .padding(.top, 10)
                    }
                }
                .padding()
                .frame(maxWidth: 500, maxHeight: 800)
                
            }
            .background(Color.cyan.opacity(0.2))
            .clipShape(RoundedRectangle(cornerRadius: 30))
        }
    }

struct nuevaRutina_Previews: PreviewProvider {
    static var previews: some View {
        nuevaRutina()
    }
}

