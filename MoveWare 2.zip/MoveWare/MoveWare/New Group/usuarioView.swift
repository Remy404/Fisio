//
//  usuarioView.swift
//  MoveWare
//
//  Created by Alumno on 08/03/24.
//

import SwiftUI

struct usuarioView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    usuarioView()
}
