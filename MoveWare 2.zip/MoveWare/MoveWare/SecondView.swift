//
//  SecondView.swift
//  MoveWare
//
//  Created by Alumno on 08/03/24.
//

import SwiftUI

struct SecondView: View {
  
  @Environment(\.dismiss) var dismiss
  
  var body: some View {
    VStack {
      Text("Segunda vista")
      
      Button(action: {
        // Cerrar la segunda vista
        dismiss()
      }) {
        Text("Volver")
      }
      .background(Color.gray.opacity(0.2))
      .cornerRadius(10)
      .padding()
    }
    .navigationTitle("Segunda vista")
  }
}
#Preview {
    SecondView()
}
