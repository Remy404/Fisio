//
//  Test.swift
//  MoveWare
//
//  Created by Alumno on 26/02/24.
//

import SwiftUI


struct Test: View {
  
  @State private var showSecondView = false
    @State private var showThirdView = false

  
  var body: some View {
    NavigationStack {
      VStack {
        Button(action: {
          self.showSecondView = true
        }) {
          Text("Ir a la segunda vista")
        }
        .background(Color.gray.opacity(0.2))
        .cornerRadius(10)
        .padding()
          Button(action: {
            self.showThirdView = true
          }) {
            Text("Ir a la tercera vista")
          }
          .background(Color.gray.opacity(0.2))
          .cornerRadius(10)
          .padding()
      }
      .navigationTitle("Primera vista")
      .navigationBarTitleDisplayMode(.inline)
      
      // Mostrar la segunda vista cuando showSecondView sea true
      .fullScreenCover(isPresented: $showSecondView) {
          SecondView()
      }
      .fullScreenCover(isPresented: $showThirdView){
            ThirdTest()
        }
      
    }
  }
}



struct EjemploApp: App {
  var body: some Scene {
    WindowGroup {
      Test()
    }
  }
}

struct Test_Previews: PreviewProvider {
    static var previews: some View {
        Test()
    }
}

